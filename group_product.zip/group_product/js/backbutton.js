$(document).ready(function() {
     noBack();
});

function noBack() {
    window.history.forward(1);
    }