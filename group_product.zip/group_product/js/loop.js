$(document).ready(function(){

	$("#add_to_cart .exclusive").remove();
});