<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{group_product}prestashop>front_c4648fdb6f19fa42a511e9972b63d5e6'] = 'Var snäll och skriv in text';
$_MODULE['<{group_product}prestashop>front_a72ea5ece242788761b29bf3401f98f5'] = 'Du är på väg att avbryta köpet av \"';
$_MODULE['<{group_product}prestashop>front_e7e652f5a4162db37641b9d322e45306'] = '\" och ta bort alla gjorda val. Vill du verkligen det?';
$_MODULE['<{group_product}prestashop>front_f52bf4355c9cd303b647200b804ba58b'] = 'Ja tack, lägg till';
$_MODULE['<{group_product}prestashop>front_96c8a62d3d8a8ed78b54f77687df42a9'] = 'Nej tack, fortsätt';
$_MODULE['<{group_product}prestashop>front_0557fa923dcee4d0f86b1409f5c2167f'] = 'Tillbaka';
$_MODULE['<{group_product}prestashop>front_638f592f71fc3fac3351534e69f9d29f'] = 'Lägg till i varukorg';
$_MODULE['<{group_product}prestashop>group_product_95adcc06d48f2ed943290902561added'] = 'CC';
$_MODULE['<{group_product}prestashop>group_product_5fb773501083652c1d1708c93e4e95fb'] = 'Gruppera produkterna';
$_MODULE['<{group_product}prestashop>group_product_7f04b3b7c0253a57330109120f828b27'] = 'Konfigurera gömda katergorier';
$_MODULE['<{group_product}prestashop>group_product_c9cc8cce247e49bae79f15173ce97354'] = 'Spara';
$_MODULE['<{group_product}prestashop>group_product_597582c140dd691b522fe42299a24d34'] = 'Inställningarna uppdaterade';
$_MODULE['<{group_product}prestashop>group_product_7278125be8c9aceaaf5d3f7645b45c5c'] = 'Inställningarna sparade';
$_MODULE['<{group_product}prestashop>shopping-cart-product-line_f2a6c498fb90ee345d997f888fce3b18'] = 'Ta bort';
$_MODULE['<{group_product}prestashop>shopping-cart-product-line_7dce122004969d56ae2e0245cb754d35'] = 'Redigera';
